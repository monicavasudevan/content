MARK=0
echo "=============Q1============="
WC1=`ansible all -m command -a 'id' | grep "uid=0(root)"  |wc -l`
if [ $WC1 -eq 4 ]
then
  echo "The inventory file is available"
  MARK=$((MARK+10))
else
  echo "The inventory under ansible folder is not available"
fi
echo "=============Q1END============="     
sleep 2
 
 
echo "=============Q2============="
WC2=`ansible all -m command -a 'yum repolist all' |grep CHANGED |wc -l`
if [ $WC2 -eq 4 ]
then
  echo "Repositories are enabled"
  MARK=$((MARK+10))
else
  echo "Repositories are not available ... plz check again....."
fi
echo "=============Q2END=============" 
sleep 2
 
 
echo "=============Q3============="
A1=`ls collections/ansible_collections |egrep "ansible" |wc -l`
A2=`ls collections/ansible_collections |egrep "redhat" |wc -l`
WC3=$((A1+A2))
if [ $WC3 -eq 2 ]
then
  echo "Collections are Available"
  MARK=$((MARK+10))
else
  echo "Collections  are not available ... plz check again....."
fi
echo "=============Q3END=============" 
sleep 2
 
echo "=============Q4============="
A3=`ls -ld roles/balancer/ |grep "roles/balancer/" |wc -l`
A4=`ls -ld roles/phpinfo/ |grep "roles/phpinfo/" |wc -l`
WC4=$((A3+A4))
if [ $WC4 -eq 2 ]
then
  echo "Roles are Available"
  MARK=$((MARK+10))
else
  echo "Roles  are not available ... plz check again....."
fi
echo "=============Q4END=============" 
sleep 2
 
echo "=============Q5============="
WC5=`curl http://servera.lab.example.com |grep "My host is servera.lab.example.com on 172.25.250.10" |wc -l`
 
if [ $WC5 -eq 1 ]
then
  echo "Apache role is Available"
  MARK=$((MARK+10))
else
  echo "Apache role is not available ... plz check again....."
fi
echo "=============Q5END=============" 
sleep 2
 
echo "=============Q6============="
WC6=`curl http://serverd.lab.example.com |wc -l`
if [ $WC6 -eq 1 ]
then
  echo "Apache role is Available"
  MARK=$((MARK+10))
else
  echo "Apache role is not available ... plz check again....."
fi
echo "=============Q6END=============" 
sleep 2
 
echo "=============Q7(A)============="
WC7A=`ansible all -m command -a 'cat /etc/chrony.conf' | grep 'server 172.25.254.254 iburst' | wc -l`
if [ $WC7A -eq 4 ]
then
  echo "Timesync is Available"
  MARK=$((MARK+10))
else
  echo "Timesync is not available ... plz check again....."
fi
echo "=============Q7(A)END=============" 
sleep 2
 
 
 
echo "=============Q7(B)============="
WC7B=`ansible all -m command -a "cat /etc/selinux/config" |grep "SELINUX=enforcing"  |wc -l`
if [ $WC7B -eq 4 ]
then
  echo "SELinux is Available"
  MARK=$((MARK+10))
else
  echo "SELinux is not available ... plz check again....."
fi
echo "=============Q7(B)END=============" 
sleep 2
 
echo "=============Q8============="
B1=`ansible dev -m command -a 'yum list installed |grep vsftpd |grep mariadb' |wc -l`
B2=`ansible prod -m command -a 'yum group list' |grep "RPM Development Tools" |wc -l`
WC8=$((B1+B2))
if [ $WC8 -eq 5 ]
then
  echo "Packages are  Available"
  MARK=$((MARK+10))
else
  echo "Packages are not available ... plz check again....."
fi
echo "=============Q8END=============" 
sleep 2
 
echo "=============Q9============="
WC9=`curl http://servera.lab.example.com/devweb/ |grep Development |wc -l`

if [ $WC9 -eq 1 ]
then
  echo "Webcontent is available"
  MARK=$((MARK+10))
else
  echo "Webcontent is not available.. plz check...."
fi
echo "=============Q9END============="     
sleep 2
 
echo "=============Q10============="
C1=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "HOSTNAME"|wc -l`
C2=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "MEMORY"|wc -l`
C3=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "BIOS"|wc -l`
C4=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "CPU"|wc -l`
C5=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "DISK_SIZE_VDA"|wc -l`
C6=`ansible all -m command -a 'cat /root/hwreport.txt' |grep "DISK_SIZE_VDB"|wc -l`

WC10=$((C1+C2+C3+C4+C5+C6))
if [ $WC10 -eq 24 ]
then
  echo "Hardware Report is available"
  MARK=$((MARK+10))
else
  echo "Hardware Report is not available.. plz check...."
fi 
echo "=============Q10END============="     
sleep 2


echo "=============Q11============="
D1=`ansible dev -m command -a 'cat /etc/issue' |grep "Development"| wc -l `
D2=`ansible test -m command -a 'cat /etc/issue' |grep "Test"|wc -l`
D3=`ansible prod -m command -a 'cat /etc/issue' |grep "Production"| wc -l` 
WC11=$((D1+D2+D3))
if [ $WC11 -eq 3 ]
then
  echo "Relapaced file  is available"
  MARK=$((MARK+10))
else
  echo "Replaced file is not available.. plz check...."
fi
echo "=============Q11END============="     
sleep 2

echo "=============Q12============="
E1=`ansible dev -m command -a 'cat /etc/myhosts' | grep '172.25.250.10 servera.lab.example.com servera' | wc -l`
E2=`ansible dev -m command -a 'cat /etc/myhosts' | grep '172.25.250.11 serverb.lab.example.com serverb' | wc -l`
E3=`ansible dev -m command -a 'cat /etc/myhosts' | grep '172.25.250.12 serverc.lab.example.com serverc' | wc -l`
E4=`ansible dev -m command -a 'cat /etc/myhosts' | grep '172.25.250.13 serverd.lab.example.com serverd' | wc -l`
WC12=$((E1+E2+E3+E4))
if [ $WC12 -eq 4 ]
then
  echo "Hosts file  is available"
  MARK=$((MARK+10))
else
  echo "Hosts file is not available.. plz check...."
fi 
echo "=============Q12END============="     
sleep 2


echo "=============Q13============="
F1=`ansible-vault view vault.yml --vault-password-file=secret.txt |grep lamdev |wc -l`
F2=`ansible-vault view vault.yml --vault-password-file=secret.txt |grep lammgr |wc -l`
WC13=$((F1+F2))
if [ $WC13 -eq 2 ]
then
  echo "Vault file is  Available"
  MARK=$((MARK+10))
else
  echo "Vault file is not available ... plz check again....."
fi
echo "=============Q13END=============" 
sleep 2


echo "=============Q14============="
G1=`ansible dev -m command -a 'tail /etc/group' |grep opsdev |wc -l`
G2=`ansible test -m command -a 'tail /etc/group' |grep opsmgr |wc -l`
G3=`ansible test -m command -a 'tail /etc/group' |grep opsdev |wc -l`
WC14=$((G1+G2+G3))
if [ $WC14 -eq 3 ]
then
  echo "Groups are  Available"
  MARK=$((MARK+10))
else
  echo "Groups are not available ... plz check again....."
fi
echo "=============Q14END=============" 
sleep 2


echo  "============Q15================"
WC15=`ansible-vault view solaris.yml --vault-password-file=password.txt |grep "Welcome to Oselabs.com" |wc -l`

if [ $WC15 -eq 1 ]
then
  echo "Rekey is available"
  MARK=$((MARK+10))
else
  echo "Rekey is not available.. plz check...."
fi
echo "=============Q15END=============" 
sleep 2      


echo  "============Q16================"
WC16=`ansible all -m command -a 'crontab -lu student' |grep "EX294 is in progress" |wc -l`

if [ $WC16 -eq 4 ]
then
  echo "Crontab is available"
  MARK=$((MARK+10))
else
  echo "Crontab is not available.. plz check...."
fi
echo "=============Q16END============="
sleep 2


echo  "============Q17================"
I1=`ansible all -m command -a 'lsblk' |grep "research-data" |wc -l`
I2=`ansible all -m command -a 'lsblk -fp' |grep "/dev/mapper/research-data ext3"|wc -l`
WC17=$((I1+I2))

if [ $WC17 -eq 8 ]
then
  echo "LVM is created"
  MARK=$((MARK+10))
else
  echo "LVM is not created.. plz check...."
fi
echo "=============Q17END=============" 
sleep 2


echo "Total Mark -----> $MARK"




